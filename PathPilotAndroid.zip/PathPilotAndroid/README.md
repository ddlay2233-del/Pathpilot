# PathPilot Android starter (0.1.0)

An early Android prototype for Malaysia-first navigation. It uses real online map tiles, place search and road routing APIs. It does **not** claim to provide live traffic, turn-by-turn voice guidance, offline maps, community reporting, or emergency dispatch.

## Requirements
- Android Studio (current stable)
- JDK 17 (Android Studio's bundled JDK is usually suitable)
- Internet connection
- Android phone or emulator running Android 8.0 (API 26) or later

## Run it
1. Unzip `PathPilotAndroid.zip`.
2. Open the `PathPilotAndroid` folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK platform (compile SDK 35).
4. Run the `app` configuration on an emulator or Android device.
5. Accept internet access (normal) and, if desired, location permission.
6. Search for a destination such as `Petronas Twin Towers, Kuala Lumpur`, then tap **Find route**.

## What works in this starter
- OpenStreetMap-based map tiles through osmdroid
- Destination lookup through Nominatim
- Road route and distance/duration from OSRM's public demo router
- Optional use of Android's last-known location (not continuous GPS tracking)
- Route line and start/end markers

## Important service limits
- **Nominatim public service** is capacity-limited and governed by its usage policy. It is not a bulk/autocomplete or guaranteed production geocoding service. Read https://operations.osmfoundation.org/policies/nominatim/
- **OSRM demo server** is a demonstration endpoint with no production uptime guarantee. Do not rely on it for a commercial launch. Read https://github.com/Project-OSRM/osrm-backend/wiki/Api-usage-policy
- **OpenStreetMap tile servers** have a usage policy; do not bulk download, prefetch or treat the public tile server as an unlimited free CDN. Read https://operations.osmfoundation.org/policies/tiles/
- OSRM's standard route response is not live-traffic-aware. The displayed duration is the router's estimate, not a traffic prediction.
- Before public release, provide a real contact in the User-Agent, review data licensing/attribution, use a suitable provider or self-host, and add retries/rate limits/caching as permitted.

## Current limitations
- The start defaults to a clearly labelled demo point in central Kuala Lumpur.
- The location button uses Android's last-known location only; it does not continuously track location or implement navigation guidance.
- No API key is embedded. The current public demo endpoints do not use an API key, but they have limits and can change.
- Community reports, traffic alerts, voice instructions, offline maps, accounts, safety/SOS and multi-route comparison are future work.

## Suggested next milestones
1. Add foreground location updates and a "recalculate route" flow.
2. Add destination search results and debounce/usage-policy compliance.
3. Add route alternatives and route preferences.
4. Add a backend for community reports, moderation and anti-spam controls.
5. Integrate a traffic provider with explicit coverage/licensing and cost checks.
6. Add accessibility, privacy policy, tests, and Play Store release preparation.

Map data © OpenStreetMap contributors. Routing provided by OSRM demo service.
