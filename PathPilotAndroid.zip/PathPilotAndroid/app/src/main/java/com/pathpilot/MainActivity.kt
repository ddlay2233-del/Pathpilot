package com.pathpilot

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.net.URLEncoder
import java.util.Locale

private val http = OkHttpClient()

data class RouteResult(
    val points: List<GeoPoint>,
    val distanceMeters: Double,
    val durationSeconds: Double
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        setContent { PathPilotApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PathPilotApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var destination by remember { mutableStateOf("Petronas Twin Towers, Kuala Lumpur") }
    var status by remember { mutableStateOf("Enter a destination and calculate a real road route.") }
    var busy by remember { mutableStateOf(false) }
    var route by remember { mutableStateOf<RouteResult?>(null) }
    var start by remember { mutableStateOf(GeoPoint(3.1390, 101.6869)) }
    var startLabel by remember { mutableStateOf("Demo start: Kuala Lumpur city centre") }
    var mapView by remember { mutableStateOf<MapView?>(null) }
    var destinationPoint by remember { mutableStateOf<GeoPoint?>(null) }

    val locationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            val lm = context.getSystemService(LocationManager::class.java)
            val loc: Location? = try {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                    lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                        ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                else lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            } catch (_: SecurityException) { null }
            if (loc != null) {
                start = GeoPoint(loc.latitude, loc.longitude)
                startLabel = "Start: your last known location"
                route = null
                status = "Location loaded. Search again to calculate a route."
                mapView?.controller?.animateTo(start)
                mapView?.invalidate()
            } else {
                status = "Permission granted, but no last-known location is available. Try outdoors or use the demo start."
            }
        } else status = "Location permission was not granted. You can still test routes from the demo start."
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF27A9FF),
        background = androidx.compose.ui.graphics.Color(0xFF071827),
        surface = androidx.compose.ui.graphics.Color(0xFF10283A)
    )) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Navigation, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("PathPilot", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Smarter routes. Safer journeys.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                OutlinedTextField(
                    value = destination,
                    onValueChange = { destination = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Destination") },
                    placeholder = { Text("Search a place or address") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            if (destination.isBlank()) { status = "Please enter a destination."; return@Button }
                            busy = true
                            status = "Searching place and calculating route…"
                            scope.launch {
                                try {
                                    val found = withContext(Dispatchers.IO) { geocode(destination) }
                                    val calculated = withContext(Dispatchers.IO) { fetchRoute(start, found) }
                                    destinationPoint = found
                                    route = calculated
                                    status = "Route calculated by OSRM. This is not live-traffic routing."
                                    mapView?.let { drawRoute(it, start, found, calculated) }
                                } catch (e: Exception) {
                                    status = "Could not calculate route: ${e.message ?: "network or service error"}. Check internet and try again."
                                } finally { busy = false }
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Navigation, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (busy) "Working…" else "Find route")
                    }
                    OutlinedButton(onClick = {
                        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        if (fine || coarse) {
                            val lm = context.getSystemService(LocationManager::class.java)
                            val loc = try {
                                if (fine) lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                                else lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                            } catch (_: SecurityException) { null }
                            if (loc != null) {
                                start = GeoPoint(loc.latitude, loc.longitude)
                                startLabel = "Start: your last known location"
                                route = null
                                status = "Location loaded. Search again to calculate a route."
                                mapView?.controller?.animateTo(start)
                                mapView?.invalidate()
                            } else status = "No last-known location yet. Try outdoors; GPS updates are not continuous in this starter."
                        } else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    }) {
                        Icon(Icons.Default.MyLocation, contentDescription = "Use location")
                    }
                }
                Text(startLabel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Card {
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().height(380.dp),
                        factory = { ctx ->
                            MapView(ctx).apply {
                                setTileSource(TileSourceFactory.MAPNIK)
                                setMultiTouchControls(true)
                                controller.setZoom(12.5)
                                controller.setCenter(start)
                                mapView = this
                                overlays.add(Marker(this).apply {
                                    position = start
                                    title = "Route start"
                                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                                })
                            }
                        },
                        update = { view ->
                            mapView = view
                            if (route != null && destinationPoint != null) drawRoute(view, start, destinationPoint!!, route!!)
                        }
                    )
                }
                route?.let { r ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Route summary", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text(String.format(Locale.getDefault(), "%.1f km", r.distanceMeters / 1000.0), style = MaterialTheme.typography.headlineMedium)
                            Text("Estimated driving time: ${formatDuration(r.durationSeconds)}")
                            Text("Provider: OSRM demo routing · No live traffic adjustment", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Text(status, style = MaterialTheme.typography.bodyMedium)
                HorizontalDivider()
                Text("Prototype scope", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("✓ Real map tiles (internet required)\n✓ Destination geocoding\n✓ Road route from OSRM\n✓ Optional last-known device location\n— Live traffic, turn-by-turn voice, community reports and SOS are not implemented yet.")
                Text("Map data © OpenStreetMap contributors. Routing by OSRM demo service.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun geocode(query: String): GeoPoint {
    val encoded = URLEncoder.encode(query, "UTF-8")
    val request = Request.Builder()
        .url("https://nominatim.openstreetmap.org/search?q=$encoded&format=jsonv2&limit=1")
        .header("User-Agent", "PathPilotAndroid/0.1 (prototype; configure a contact email before public release)")
        .build()
    http.newCall(request).execute().use { response ->
        if (!response.isSuccessful) error("Place search returned HTTP ${response.code}")
        val arr = JSONArray(response.body?.string() ?: "[]")
        if (arr.length() == 0) error("No matching place found")
        val item = arr.getJSONObject(0)
        return GeoPoint(item.getDouble("lat"), item.getDouble("lon"))
    }
}

private fun fetchRoute(start: GeoPoint, end: GeoPoint): RouteResult {
    val url = "https://router.project-osrm.org/route/v1/driving/" +
        "${start.longitude},${start.latitude};${end.longitude},${end.latitude}?overview=full&geometries=geojson"
    val request = Request.Builder().url(url).get().build()
    http.newCall(request).execute().use { response ->
        if (!response.isSuccessful) error("Routing returned HTTP ${response.code}")
        val root = JSONObject(response.body?.string() ?: error("Empty route response"))
        if (root.optString("code") != "Ok") error("No drivable route found")
        val r = root.getJSONArray("routes").getJSONObject(0)
        val coords = r.getJSONObject("geometry").getJSONArray("coordinates")
        val points = (0 until coords.length()).map { i ->
            val p = coords.getJSONArray(i)
            GeoPoint(p.getDouble(1), p.getDouble(0))
        }
        return RouteResult(points, r.getDouble("distance"), r.getDouble("duration"))
    }
}

private fun drawRoute(view: MapView, start: GeoPoint, end: GeoPoint, route: RouteResult) {
    view.overlays.removeAll { it is Polyline || it is Marker }
    view.overlays.add(Polyline().apply {
        setPoints(route.points)
        outlinePaint.color = android.graphics.Color.rgb(20, 145, 255)
        outlinePaint.strokeWidth = 10f
    })
    view.overlays.add(Marker(view).apply {
        position = start
        title = "Start"
        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
    })
    view.overlays.add(Marker(view).apply {
        position = end
        title = "Destination"
        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
    })
    val bounds = org.osmdroid.util.BoundingBox.fromGeoPoints(route.points)
    view.zoomToBoundingBox(bounds, true, 48)
    view.invalidate()
}

private fun formatDuration(seconds: Double): String {
    val minutes = (seconds / 60).toInt().coerceAtLeast(1)
    return if (minutes >= 60) "${minutes / 60} hr ${minutes % 60} min" else "$minutes min"
}
